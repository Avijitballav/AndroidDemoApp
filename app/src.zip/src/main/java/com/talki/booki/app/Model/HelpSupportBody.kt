package com.talki.booki.app.Model

class HelpSupportBody (private val email: String?,
                       private val name: String?,
                       private val phone: String?,
                       private val comment: String?)