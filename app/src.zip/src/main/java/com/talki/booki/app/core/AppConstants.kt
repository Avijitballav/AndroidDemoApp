package com.talki.booki.app.core

object AppConstants {

    /**
     * Variable Name
     */
    const val USER_DETAILS= "user"
    const val PREFS_LANGUAGE = "language"
    const val PREFS_LANGUAGE_CONTENT= "language_content"
    const val FILE_NAME="file_name"
    const val DEVICE_TOKEN = "device_token"
    const val CATEGORY_ID = "category_id"
    const val User_TOKEN = "User_TOKEN"

    var header_title = "header_title"
    var category_Id = "category_Id"
    var language_Id = "language_Id"
    var language_IdFlag = "language_IdFlag"
    var language_listdata = "language_listdata"
    var is_free_Id="is_free_Id"
    var answerList = "answerList"
    const val PREFS_CONSTANT_VALUE= "CONSTANT_VALUE"
    var product_id="product_id"
    const val device_type= "android"

    const val login_type_fb= "fb"
    const val login_type_g= "google"

    var PriceCurrency="INR"



    var transitionflagBack = 2
    var transitionflagNext = 1
    const val default_password = "123456"

    const val Bearer = "Bearer "

    const val Bearer_Value = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NCwiZW1haWwiOiJ0ZXN0ZGV2QGdtYWlsLmNvbSIsIm5hbWUiOiJUZXN0ZGV2IiwicGhvbmUiOm51bGwsImxvZ2luX3R5cGUiOiJmYiIsImlzX2FjdGl2ZSI6MSwiZXhwaXJlZCI6ZmFsc2UsImlhdCI6MTYzMjgxMjYwM30.fv9Af73AVYYMr0Pz0o5mqTYy6fzWkuNF3SDb2NyUZak"

    var ImagePath = "/D2App"

  /*  //************* AWS S3  Local ***************
    var AWS_S3_KEY = "AKIAYM5JZA5SP65BXQU7"
    var AWS_S3_SECRET = "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" //yO4UDOlcmgw+L2ucUDAX2QbbgmdZCMk2OM7mGXVn
    var AWS_REGION = "ap-south-1"
    var AWS_ACL = "public-read"
    var AWS_BUCKET = "businessproject"
    var AWS_Path = "https://businessproject.s3.ap-south-1.amazonaws.com/"
    var ImagePath = "/BusinessApp"
    var ImagePathS3 = "BusinessApp/"*/

   */
}