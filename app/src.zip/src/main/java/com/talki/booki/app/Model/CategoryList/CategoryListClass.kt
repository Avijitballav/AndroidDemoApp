package com.talki.booki.app.Model.CategoryList

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

class CategoryListClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("category")
    @Expose
    var category: ArrayList<Category>? = null

    @SerializedName("pagination")
    @Expose
    var pagination: Pagination? = null
}