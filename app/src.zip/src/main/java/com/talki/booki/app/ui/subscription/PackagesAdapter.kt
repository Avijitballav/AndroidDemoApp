package com.talki.booki.app.ui.subscription

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.talki.booki.app.Model.SubscriptionPackages.Package
import com.talki.booki.app.Model.categorywiseProduct.Category
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.AdapterCalegoryListBinding
import com.talki.booki.app.databinding.AdapterPackagesListBinding
import com.talki.booki.app.ui.category.CategoryListAdapter
import com.talki.booki.app.ui.payment.PaymentActivity
import com.talki.booki.app.ui.productdetails.ProductDetails
import java.util.ArrayList

class PackagesAdapter (val mContext: Context, val topic_listdata: ArrayList<Package>) :
        RecyclerView.Adapter<PackagesAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
                AdapterPackagesListBinding.inflate(
                        LayoutInflater.from(mContext),
                        parent,
                        false
                )
        )
    }

    override fun getItemCount(): Int {
        return topic_listdata.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.onBind()
    }

    inner class ViewHolder(val binding: AdapterPackagesListBinding) :
            RecyclerView.ViewHolder(binding.root) {
        fun onBind() {

            binding.tvYearly.text=topic_listdata.get(adapterPosition).packageName
            binding.tvYearlyamount.text= AppConstants.PriceCurrency +" "+topic_listdata.get(adapterPosition).price
            binding.rlPayment.setOnClickListener {
                val intent = Intent(mContext, PaymentActivity::class.java)
                mContext.startActivity(intent)

            }
        }
    }
}