package com.talki.booki.app.ui.filter

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.google.gson.Gson
import com.talki.booki.app.Model.CategoryList.Category
import com.talki.booki.app.Model.Language.Language
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.ActivityFilterBinding
import com.talki.booki.app.ui.home.LanguageViewModel
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import java.io.Serializable
import java.util.*


@AndroidEntryPoint
class Filter : AppCompatActivity() {

    private lateinit var binding : ActivityFilterBinding
    var Transitionflag = AppConstants.transitionflagNext

    //****** Data get from Home
    var category: ArrayList<String>? = ArrayList()
    var language: ArrayList<String>? = ArrayList()
    var is_free="";
    var languageList: ArrayList<Boolean>? = ArrayList()



    var Language_listdata:ArrayList<Language>?= ArrayList()
    var Category_listdata:ArrayList<Category>?= ArrayList()

    //    ******** data update in Filter Screen ***

    var category_local: ArrayList<String>? = ArrayList()
    var language_local: ArrayList<String>? = ArrayList()
    var is_free_local="";
    var languageList_local: ArrayList<Boolean>? = ArrayList()
    var CategoryList_local: ArrayList<Boolean>? = ArrayList()

    private val languageViewModel by viewModels<LanguageViewModel>()
    private val categoryViewModel by viewModels<CategoryListViewModel>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_filter)


        category=intent.getSerializableExtra(AppConstants.category_Id)  as ArrayList<String>?
        language= intent.getSerializableExtra(AppConstants.language_Id) as ArrayList<String>?
        languageList= intent.getSerializableExtra(AppConstants.language_IdFlag) as ArrayList<Boolean>?
        is_free=intent.getStringExtra(AppConstants.is_free_Id)!!

        category_local=category
        language_local=language
        is_free_local=is_free
        languageList_local=languageList


        Listener()
        fetchLanguageData()
        fetchCategoryListData()
    }

    /* Set category List view */

    fun fetchCategoryListData(){
        binding.pbloader.visibility = View.VISIBLE
        categoryViewModel.fetchCategoryResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        categoryViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        Category_listdata = response.data.category
                        for (i in 0 until Category_listdata!!.size) {
                            if(category_local!!.contains(Category_listdata!!.get(i).id.toString())) {
                                CategoryList_local!!.add(true)
                            }else{
                                CategoryList_local!!.add(false)
                            }

                        }

                        SetCategoryView()
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {

                }
            }
        }
    }

    fun SetCategoryView(){


        binding.llCategoryview.removeAllViews()

        for(i in 0 until Category_listdata!!.size){
            binding.llCategoryview.addView(getCategoryView(i))
        }
    }

    private fun  getCategoryView(position: Int): View? {
        val view: View =
                LayoutInflater.from(this).inflate(R.layout.language_cell_view, null)
        val tv_english = view.findViewById<View>(R.id.tv_english) as TextView

        if(CategoryList_local!!.get(position)){
            tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_selct),  null);
        }else{
            tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_dselct), null );
        }
        tv_english.setText(Category_listdata!!.get(position).name)

        tv_english.setOnClickListener {
            if(CategoryList_local!!.get(position)){
                CategoryList_local!!.set(position,false)
                tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_dselct),  null);
            }else{
                CategoryList_local!!.set(position,true)
                tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_selct), null );
            }
        }
        return view
    }


    /* Set Language List view */

    fun fetchLanguageData(){
        languageViewModel.fetchLanguageResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        languageViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        Language_listdata = response.data.language
                        if(languageList_local!!.size==0) {
                            for (i in 0 until Language_listdata!!.size) {
                                languageList_local!!.add(false)
                            }
                        }
                        SetLanguageView()
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {
//                    binding.pbloader.visibility = View.VISIBLE
                }
            }
        }
    }

    fun SetLanguageView(){
        binding.llLanguageview.removeAllViews()

        for(i in 0 until Language_listdata!!.size){
            binding.llLanguageview.addView(getLanguageView(i))
        }
    }

    private fun  getLanguageView(position: Int): View? {
        val view: View =
                LayoutInflater.from(this).inflate(R.layout.language_cell_view, null)
        val tv_english = view.findViewById<View>(R.id.tv_english) as TextView

        if(languageList_local!!.get(position)){
            tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_selct),  null);
        }else{
            tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_dselct), null );
        }
        tv_english.setText(Language_listdata!!.get(position).name)

        tv_english.setOnClickListener {
            if(languageList_local!!.get(position)){
                languageList_local!!.set(position,false)
                tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_dselct),  null);
            }else{
                languageList_local!!.set(position,true)
                tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_selct), null );
            }
        }

        return view
    }

    fun Listener(){
        binding.ivBack.setOnClickListener {
            Transitionflag= AppConstants.transitionflagBack
            finish()
        }

        binding.tvApply.setOnClickListener {
            Transitionflag= AppConstants.transitionflagBack
            category_local= ArrayList()
            for (i in 0 until Category_listdata!!.size) {
               if(CategoryList_local!!.get(i)){
                   category_local!!.add(Category_listdata!!.get(i).id.toString())
               }
            }
            category=category_local
            language=language_local
            languageList=languageList_local
            is_free=is_free_local

            val intent = Intent()
            intent.putExtra(AppConstants.category_Id, category as Serializable?)
            intent.putExtra(AppConstants.language_Id,  language as Serializable?)
            intent.putExtra(AppConstants.language_IdFlag,  languageList as Serializable?)
            intent.putExtra(AppConstants.is_free_Id, is_free)

            setResult(-1, intent)
            finish()
        }

        binding.tvClear.setOnClickListener {
            category_local= ArrayList()
            language_local= ArrayList()
            is_free_local="";
            languageList_local= ArrayList()
            CategoryList_local= ArrayList()

            if(languageList_local!!.size==0) {
                for (i in 0 until Language_listdata!!.size) {
                    languageList_local!!.add(false)
                }
            }

            if(CategoryList_local!!.size==0) {
                for (i in 0 until Category_listdata!!.size) {
                    CategoryList_local!!.add(false)
                }
            }
            SetLanguageView()
            SetCategoryView()

        }
    }

    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, Transitionflag) // Screen transition animation
    }
}