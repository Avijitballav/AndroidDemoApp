package com.talki.booki.app.Model.categorywiseProduct

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CatProduct {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("thumbnail")
    @Expose
    var thumbnail: String? = null

    @SerializedName("author")
    @Expose
    var author: String? = null

    @SerializedName("language_id")
    @Expose
    var languageId: Int? = null

    @SerializedName("is_free")
    @Expose
    var isFree: Int? = null
}