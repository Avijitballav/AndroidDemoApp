package com.talki.booki.app.Model

class LogoutBody (private val device_type: String?,
                  private val device_token: String?,
                  private val device_id: String?)