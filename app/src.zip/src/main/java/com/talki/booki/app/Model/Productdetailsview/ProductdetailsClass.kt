package com.talki.booki.app.Model.Productdetailsview

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ProductdetailsClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("product")
    @Expose
    var product: Product? = null

    @SerializedName("similar_product")
    @Expose
    var similarProduct: ArrayList<SimilarProduct>? = null

    @SerializedName("is_subscribed")
    @Expose
    var isSubscribed: Int? = null
}