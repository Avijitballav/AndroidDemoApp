package com.talki.booki.app.fcm

import android.annotation.TargetApi
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat


import com.talki.booki.app.utils.Prefs
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants.DEVICE_TOKEN
import com.talki.booki.app.ui.Splash


class TalkiBookiMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        Log.d(getString(R.string.app_name), "remoteMessage 1  $remoteMessage")
        Log.d(getString(R.string.app_name), "remoteMessage 2 " + remoteMessage.data)

        remoteMessage?.notification?.let {
            Log.d("MESSAGE", "Message Notification Body: ${it.body}")
            val title = it.title
            val message = it.body
            val mIntent = Intent()
            val resultIntent = Intent(this, Splash::class.java)
            resultIntent.addCategory(Intent.CATEGORY_DEFAULT)
            sendBroadcast(mIntent)
            showNotification(resultIntent, title, message)

        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    private fun showNotification(resultIntent : Intent = Intent(), title : String?, message : String?){

        val mNotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val CHANNEL_ID = "talkibooki.android_channel_01"
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val name = "talkibooki.android_channel"
            val Description = "Talkibooki Notification Channel"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val mChannel = NotificationChannel(CHANNEL_ID, name, importance)
            mChannel.description = Description
            mChannel.enableLights(true)
            mChannel.lightColor = Color.RED
            mChannel.enableVibration(true)
            mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
            mChannel.setShowBadge(false)
            mNotificationManager.createNotificationChannel(mChannel)
        }
        val drawable = ContextCompat.getDrawable(this, R.mipmap.ic_launcher);
        val bitmap = (drawable as BitmapDrawable).bitmap
        val mBuilder = NotificationCompat.Builder(this,CHANNEL_ID)
        mBuilder.setSmallIcon(R.mipmap.ic_launcher)
        mBuilder.setLargeIcon(bitmap)
        mBuilder.setContentTitle(title)
        mBuilder.setContentText(message)
        val pendingIntent = PendingIntent.getActivity(this, 0, resultIntent,PendingIntent.FLAG_UPDATE_CURRENT)
        mBuilder.setContentIntent(pendingIntent)
        mBuilder.setAutoCancel(true)
        val notification = mBuilder.build()
        notification.flags = Notification.FLAG_AUTO_CANCEL
        notification.defaults = Notification.DEFAULT_LIGHTS or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_SOUND
        // notificationID allows you to update the notification later on.
        mNotificationManager.notify(1, notification)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(getString(R.string.app_name),token)
        if( Prefs.with(baseContext.applicationContext).read(DEVICE_TOKEN,"").equals("")){
            Log.d(getString(R.string.app_name),"Added")
            Prefs.with(baseContext.applicationContext).write(DEVICE_TOKEN,token)
        }

    }

}