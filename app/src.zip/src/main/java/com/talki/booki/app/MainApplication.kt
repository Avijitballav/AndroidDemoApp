package com.talki.booki.app

import android.app.Application
import android.content.res.Resources
import androidx.databinding.library.BuildConfig
import androidx.multidex.MultiDex
import com.facebook.FacebookSdk
import com.facebook.appevents.AppEventsLogger
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()
       /* if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }*/

        MainApplication.applicationInstance = this
        MultiDex.install(MainApplication.applicationInstance)
        MainApplication.instance = this
        MainApplication.resourses = resources

        setupFacebookSDK()
    }

    private fun setupFacebookSDK() {
        FacebookSdk.sdkInitialize(applicationContext)
        AppEventsLogger.activateApp(this)
    }

    companion object {
        lateinit var applicationInstance: MainApplication
        lateinit var instance: Application
        lateinit var resourses: Resources
    }

}