package com.talki.booki.app.ui.notification

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.talki.booki.app.Model.HomeFilter
import com.talki.booki.app.Model.LogoutBody
import com.talki.booki.app.Model.Notification.Notification
import com.talki.booki.app.Model.NotificationBody
import com.talki.booki.app.Model.categorywiseProduct.Category
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.ActivityNotificationBinding
import com.talki.booki.app.ui.helpsuport.HelpSupport
import com.talki.booki.app.ui.home.CategorywiseProductViewModel
import com.talki.booki.app.ui.profile.MyProfile
import com.talki.booki.app.utils.AndroidUtility
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class Notifications : AppCompatActivity() {

    private lateinit var mNotificationAdapter: NotificationAdapter
    var layoutManager: LinearLayoutManager?=null

    private lateinit var binding : ActivityNotificationBinding

    private val notificationViewModel by viewModels<NotificationViewModel>()
    var Notification_listdata: ArrayList<Notification>?= ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_notification)


        initView()
        Listener()
        fetchNotificationData()
    }

    fun initView(){
        layoutManager = LinearLayoutManager(this@Notifications)


    }

    fun Listener(){
        binding.tvBottomHome.setOnClickListener {
            finish()

        }

        binding.tvBottomHelp.setOnClickListener {
            val intent = Intent(this@Notifications, HelpSupport::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvBottomAccount.setOnClickListener {
            val intent = Intent(this@Notifications, MyProfile::class.java)
            startActivity(intent)
            finish()
        }
    }


    private fun fetchNotificationData() {
        var device_type= AppConstants.device_type
        var device_token=Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN,"")
        val device_id = AndroidUtility.getAndroidDeviceId(this)

        val task = NotificationBody(device_type,device_token,device_id)

        Log.d(getString(R.string.app_name), "*********task***" + Gson().toJson(task));

        binding.pbloader.visibility = View.VISIBLE
        notificationViewModel.notificationListResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value), task)
        notificationViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        Notification_listdata = response.data.notifications

                        mNotificationAdapter=NotificationAdapter(this,Notification_listdata!!)
                        val categoryTopicListLayoutManager = binding.rvCNotificationList.layoutManager as GridLayoutManager
                        binding.rvCNotificationList.layoutManager = categoryTopicListLayoutManager
                        categoryTopicListLayoutManager.spanCount = 1
                        binding.rvCNotificationList.adapter = mNotificationAdapter
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(this, "" + response!!.data!!.message, Toast.LENGTH_SHORT).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }
}