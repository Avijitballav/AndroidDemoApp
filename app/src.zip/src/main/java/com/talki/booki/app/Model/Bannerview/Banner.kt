package com.talki.booki.app.Model.Bannerview

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Banner {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("product_id")
    @Expose
    var productId: Any? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: Any? = null

    @SerializedName("updated_by")
    @Expose
    var updatedBy: Any? = null

    @SerializedName("is_active")
    @Expose
    var isActive: Int? = null

    @SerializedName("is_deleted")
    @Expose
    var isDeleted: Int? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: Any? = null

    @SerializedName("deleted_at")
    @Expose
    var deletedAt: Any? = null
}