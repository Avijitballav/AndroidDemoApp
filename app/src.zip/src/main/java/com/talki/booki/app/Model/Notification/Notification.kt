package com.talki.booki.app.Model.Notification

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class Notification {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("title")
    @Expose
    var title: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null
}