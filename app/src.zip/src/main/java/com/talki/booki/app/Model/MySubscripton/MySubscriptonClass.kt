package com.talki.booki.app.Model.MySubscripton

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MySubscriptonClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("is_subscribed")
    @Expose
    var isSubscribed: Int? = null

    @SerializedName("mysubscriptionpackage")
    @Expose
    var mysubscriptionpackage: Mysubscriptionpackage? = null
}