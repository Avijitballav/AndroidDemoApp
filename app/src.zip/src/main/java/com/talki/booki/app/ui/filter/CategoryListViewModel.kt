package com.talki.booki.app.ui.filter

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.talki.booki.app.Model.Bannerview.BannerviewClass
import com.talki.booki.app.Model.CategoryList.CategoryListClass
import com.talki.booki.app.data.remote.Repository
import com.talki.booki.app.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CategoryListViewModel  @Inject constructor
(
        private val repository: Repository,
        application: Application
) : AndroidViewModel(application) {

    private val _response: MutableLiveData<NetworkResult<CategoryListClass>> = MutableLiveData()
    val response: LiveData<NetworkResult<CategoryListClass>> = _response

    fun fetchCategoryResponse(token:String) = viewModelScope.launch {
        repository.getCategory(token).collect { values ->
            _response.value = values
        }
    }

}