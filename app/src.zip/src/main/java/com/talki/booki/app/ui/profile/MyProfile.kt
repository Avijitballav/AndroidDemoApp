package com.talki.booki.app.ui.profile

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.acumen.glow.app.callbacks.CallBackButtonClick
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.squareup.picasso.Picasso
import com.talki.booki.app.BuildConfig
import com.talki.booki.app.Model.LanguageBody
import com.talki.booki.app.Model.Loginiew.LoginviewClass
import com.talki.booki.app.Model.Loginiew.User
import com.talki.booki.app.Model.LogoutBody
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.ActivityMyProfileBinding
import com.talki.booki.app.dialog.BottomSheetDialogPositiveNegative
import com.talki.booki.app.ui.helpsuport.HelpSupport
import com.talki.booki.app.ui.login.Login
import com.talki.booki.app.ui.notification.Notifications
import com.talki.booki.app.ui.subscription.MySubscription
import com.talki.booki.app.utils.AndroidUtility
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MyProfile : AppCompatActivity(), CallBackButtonClick {

    private lateinit var binding : ActivityMyProfileBinding
    val gson = GsonBuilder().setPrettyPrinting().create()
    lateinit var userinfoModel: LoginviewClass
    private val myprofileViewModel by viewModels<MyprofileViewModel>()
    private val logoutViewModel by viewModels<LogoutViewModel>()
    var Transitionflag = AppConstants.transitionflagNext

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_profile)
        userinfoModel = gson.fromJson(Prefs.with(this).read(AppConstants.USER_DETAILS, ""), LoginviewClass::class.java)



        binding.tvusername.text=userinfoModel.user!!.name

        Picasso.get()
                .load(userinfoModel.user!!.profile_img)
                .placeholder(R.drawable.ic_no_imagemotivation_one)
                .error(R.drawable.ic_no_imagemotivation_one)
                .into(binding.ivProfileimage)


        initView()
        Listener()

    }

    fun initView(){

    }

    fun Listener(){
        binding.tvBottomHome.setOnClickListener {
            finish()

        }

        binding.tvEdit.setOnClickListener {
            val intent = Intent(this@MyProfile, EditProfile::class.java)
            startActivity(intent)

        }

        binding.tvBottomHelp.setOnClickListener {
            val intent = Intent(this@MyProfile, HelpSupport::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvBottomNotification.setOnClickListener {
            val intent = Intent(this@MyProfile, Notifications::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvShare.setOnClickListener {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Hey check out " + getString(R.string.app_name) + " at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID
            )
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        }

        binding.tvMySubscription.setOnClickListener {

            val intent = Intent(this@MyProfile, MySubscription::class.java)
            startActivity(intent)

        }

        binding.tvLogout.setOnClickListener {
            val bsd = BottomSheetDialogPositiveNegative(
                    this@MyProfile,
                    this@MyProfile, this@MyProfile,
                    this@MyProfile.getResources().getString(R.string.Logout_alert_msg),
                    this@MyProfile.getResources().getString(R.string.Yes),
                    this@MyProfile.getResources().getString(R.string.No)
            )
        }
    }


    override fun onResume() {
        super.onResume()
        fetchProfileData()

    }

    fun  fetchProfileData(){
        binding.pbloader.visibility = View.VISIBLE
        myprofileViewModel.fetchMyprofileResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        myprofileViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        //*** Locally update user details
                        val gson = GsonBuilder().setPrettyPrinting().create()
                        val str_userdetails: String? = gson.toJson(response.data.user)
                        var userdetils = gson.fromJson(str_userdetails, User::class.java)
                        userinfoModel.user = userdetils
                        Prefs.with(this).write(AppConstants.USER_DETAILS, gson.toJson(userinfoModel))

                        //********* Set user info


                        Picasso.get()
                                .load(response.data.user!!.profileImg)
                                .placeholder(R.drawable.ic_no_imagemotivation_one)
                                .error(R.drawable.ic_no_imagemotivation_one)
                                .into(binding.ivProfileimage)

                        binding.tvusername.text = response.data.user!!.name
                        if (response.data.isSubscribed == 1) {
                            binding.tvusertype.text = getString(R.string.You_are_a_paid_user)
                        } else {
                            binding.tvusertype.text = getString(R.string.You_are_a_free_user)
                        }

                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {

                }
            }
        }
    }

    override fun onButtonClick(strButtonText: String) {
        if(getResources().getString(R.string.Yes).equals(strButtonText)){

            LogoutUser()
        }
    }

    fun LogoutUser(){

        var device_type= AppConstants.device_type
        var device_token=Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN,"")
        val device_id = AndroidUtility.getAndroidDeviceId(this)

        val task = LogoutBody(device_type,device_token,device_id)
        Log.d(getString(R.string.app_name), "" + Gson().toJson(task))
        binding.pbloader.visibility = View.VISIBLE
        logoutViewModel.fetchlogoutResponse(task,Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        logoutViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        Transitionflag=AppConstants.transitionflagBack
                        Prefs.with(this).write(AppConstants.USER_DETAILS, "")
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        val intent = Intent(this, Login::class.java)
                        startActivity(intent)
                        finishAffinity()


                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {

                }
            }
        }
    }

    override fun onButtonClick(ff_pos: Int, ImagePos: Int) {

    }
}