package com.talki.booki.app.Model.Notification

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class NotificationClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("notifications")
    @Expose
    var notifications: ArrayList<Notification>? = null

    @SerializedName("pagination")
    @Expose
    var pagination: Pagination? = null
}