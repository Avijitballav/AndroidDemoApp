package com.talki.booki.app.Model.getProfile

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class getprofileClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("user")
    @Expose
    var user: User? = null

    @SerializedName("is_subscribed")
    @Expose
    var isSubscribed: Int? = null
}