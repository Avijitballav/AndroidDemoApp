package com.talki.booki.app.addview

import android.app.Activity
import android.app.Notification
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import com.talki.booki.app.R
import com.talki.booki.app.ui.helpsuport.HelpSupport
import com.talki.booki.app.ui.home.HomeActivity
import com.talki.booki.app.ui.notification.Notifications
import com.talki.booki.app.ui.profile.MyProfile

class BottomviewContent {

    var mContext: Activity? = null
    var v: View? = null

    var tv_bottomhome:TextView?=null
    var tv_bottomhelp:TextView?=null
    var tv_bottomnotification:TextView?=null
    var tv_bottomAccount:TextView?=null

    fun bottomView(activity: Activity?): View? {

        mContext = activity


        v = LayoutInflater.from(mContext).inflate(R.layout.bottom_view, null)
        initialize()
        listener()
        return v
    }

    private fun initialize() {
        tv_bottomhome=v!!.findViewById(R.id.tv_bottomHome)
        tv_bottomhelp=v!!.findViewById(R.id.tv_bottomHelp)
        tv_bottomnotification=v!!.findViewById(R.id.tv_bottomNotification)
        tv_bottomAccount=v!!.findViewById(R.id.tv_bottomAccount)

        if (mContext is HomeActivity) {
            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_select), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_dselect), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_dselect), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_dselect), null, null, null);

        }else if (mContext is HelpSupport) {
            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_dselect), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_select), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_dselect), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_dselect), null, null, null);

        }else if (mContext is com.talki.booki.app.ui.notification.Notifications) {
            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_dselect), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_dselect), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_select), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_dselect), null, null, null);

        }else if (mContext is MyProfile) {
            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_dselect), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_dselect), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_dselect), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_select), null, null, null);

        }
    }



    private fun listener() {

        tv_bottomhome!!.setOnClickListener {
//            if (!(mContext is HomeActivity)) {
//                mContext!!.finish()
//            }
            val intent = Intent(mContext, HomeActivity::class.java)
            mContext!!.startActivity(intent)
            mContext!!.finish()

            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_select), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_dselect), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_dselect), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_dselect), null, null, null);

        }

        tv_bottomhelp!!.setOnClickListener {
           /* if ((mContext is HomeActivity)) {
                val intent = Intent(mContext, HelpSupport::class.java)
                mContext!!.startActivity(intent)
            } else if (!(mContext is HelpSupport)) {
                val intent = Intent(mContext, HelpSupport::class.java)
                mContext!!.startActivity(intent)
                mContext!!.finish()
            }
*/
            val intent = Intent(mContext, HelpSupport::class.java)
            mContext!!.startActivity(intent)
            mContext!!.finish()
            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_dselect), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_select), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_dselect), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_dselect), null, null, null);

        }
        tv_bottomnotification!!.setOnClickListener {
//            if ((mContext is HomeActivity)) {
//                val intent = Intent(mContext, Notification::class.java)
//                mContext!!.startActivity(intent)
//            } else if (!(mContext is Notification)) {
//                val intent = Intent(mContext, Notification::class.java)
//                mContext!!.startActivity(intent)
//                mContext!!.finish()
//            }
            val intent = Intent(mContext, Notifications::class.java)
            mContext!!.startActivity(intent)
            mContext!!.finish()

            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_dselect), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_dselect), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_select), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_dselect), null, null, null);

        }

        tv_bottomAccount!!.setOnClickListener {
        /*    if ((mContext is HomeActivity)) {
                val intent = Intent(mContext, MyProfile::class.java)
                mContext!!.startActivity(intent)
            } else if (!(mContext is MyProfile)) {
                val intent = Intent(mContext, MyProfile::class.java)
                mContext!!.startActivity(intent)
                mContext!!.finish()
            }*/

            val intent = Intent(mContext, MyProfile::class.java)
            mContext!!.startActivity(intent)
            mContext!!.finish()

            tv_bottomhome!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_home_dselect), null, null, null)
            tv_bottomhelp!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_help_support_dselect), null, null, null);
            tv_bottomnotification!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_notification_dselect), null, null, null);
            tv_bottomAccount!!.setCompoundDrawables(mContext!!.getResources().getDrawable(R.drawable.ic_my_account_select), null, null, null);

        }

    }


}