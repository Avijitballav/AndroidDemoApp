package com.talki.booki.app.ui.category

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.talki.booki.app.Model.HomeFilter
import com.talki.booki.app.Model.categorywiseProduct.Category
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.ActivityCategoryListBinding
import com.talki.booki.app.ui.home.CategorywiseProductViewModel
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class CategoryList : AppCompatActivity() {
    private lateinit var binding : ActivityCategoryListBinding

    private lateinit var mCategoryListAdapter: CategoryListAdapter
    var layoutManager: LinearLayoutManager?=null
    var topic_listdata: ArrayList<Int>?= ArrayList()

   var Transitionflag = AppConstants.transitionflagNext
    var header_title=""
    var category_Id=""
    var language: ArrayList<String> = ArrayList()
    var category: ArrayList<String> = ArrayList()
    var is_free="";

    private val mainViewModel by viewModels<CategorywiseProductViewModel>()
    var Category_listdata:ArrayList<Category>?= ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_category_list)
        header_title=intent.getStringExtra(AppConstants.header_title)!!

        category_Id=intent.getStringExtra(AppConstants.category_Id)!!
        category.add(category_Id)

        language= intent.getSerializableExtra(AppConstants.language_Id) as ArrayList<String>
        is_free=intent.getStringExtra(AppConstants.is_free_Id)!!

        binding.tvCattitle.text=header_title




        initView()
        Listener()
        fetchcategoryData()

    }




    fun initView(){
        layoutManager = LinearLayoutManager(this@CategoryList)

    }

    fun Listener(){
        binding.toolbarHeaderContent.ivBack.setOnClickListener {
            Transitionflag=AppConstants.transitionflagBack
            finish()
        }
    }


    private fun fetchcategoryData() {

        val task = HomeFilter(category, language, is_free)
        Log.d(getString(R.string.app_name), "*********task***" + Gson().toJson(task));

        binding.pbloader.visibility = View.VISIBLE
        mainViewModel.fetchCategotyListResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value), task)
        mainViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(
                            getString(R.string.app_name),
                            "**********position**" + response.data.status
                        )

                        Category_listdata = response.data.category

                        SetCatagoryView()
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this,
                        "" + response!!.data!!.messgae,
                        Toast.LENGTH_SHORT
                    ).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }

    fun SetCatagoryView(){



        mCategoryListAdapter=CategoryListAdapter(this, Category_listdata!!)
        val categoryTopicListLayoutManager = binding.rvCTopicList.layoutManager as GridLayoutManager
        binding.rvCTopicList.layoutManager = categoryTopicListLayoutManager
        categoryTopicListLayoutManager.spanCount = 2
        binding.rvCTopicList.adapter = mCategoryListAdapter
    }

    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, Transitionflag) // Screen transition animation
    }
}