package com.talki.booki.app.Model.MySubscripton

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Mysubscriptionpackage {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("user_id")
    @Expose
    var userId: Int? = null

    @SerializedName("package_id")
    @Expose
    var packageId: Int? = null

    @SerializedName("price")
    @Expose
    var price: Int? = null

    @SerializedName("start_date")
    @Expose
    var startDate: String? = null

    @SerializedName("end_date")
    @Expose
    var endDate: String? = null

    @SerializedName("is_active")
    @Expose
    var isActive: Int? = null

    @SerializedName("is_deleted")
    @Expose
    var isDeleted: Int? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: Int? = null

    @SerializedName("updated_by")
    @Expose
    var updatedBy: Int? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null
}