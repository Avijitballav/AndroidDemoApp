package com.talki.booki.app.Model

import java.util.*

class HomeFilter (private val category: ArrayList<String>?,
                  private val language: ArrayList<String>?,
                  private val is_free: String?)