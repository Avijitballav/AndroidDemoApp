package com.talki.booki.app.ui.subscription

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.talki.booki.app.Model.Bannerview.BannerviewClass
import com.talki.booki.app.Model.MySubscripton.MySubscriptonClass
import com.talki.booki.app.data.remote.Repository
import com.talki.booki.app.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class MySubscriptionViewModel @Inject constructor
(
        private val repository: Repository,
        application: Application
) : AndroidViewModel(application) {

    private val _response: MutableLiveData<NetworkResult<MySubscriptonClass>> = MutableLiveData()
    val response: LiveData<NetworkResult<MySubscriptonClass>> = _response

    fun fetchMySubscriptionResponse(token:String) = viewModelScope.launch {
        repository.getMySubscription(token).collect { values ->
            _response.value = values
        }
    }

}