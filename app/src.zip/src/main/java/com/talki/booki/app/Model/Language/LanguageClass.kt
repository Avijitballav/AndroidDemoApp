package com.talki.booki.app.Model.Language

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

class LanguageClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("language")
    @Expose
    var language: ArrayList<Language>? = null

    @SerializedName("pagination")
    @Expose
    var pagination: Pagination? = null
}