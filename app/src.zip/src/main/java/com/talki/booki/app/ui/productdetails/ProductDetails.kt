package com.talki.booki.app.ui.productdetails

import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaPlayer.OnPreparedListener
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.multidex.BuildConfig
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import com.talki.booki.app.Model.LogoutBody
import com.talki.booki.app.Model.ProductDetailsBody
import com.talki.booki.app.Model.Productdetailsview.SimilarProduct
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.core.AppConstants.device_type
import com.talki.booki.app.databinding.ActivityProductDetailsBinding
import com.talki.booki.app.ui.category.CategoryList
import com.talki.booki.app.utils.AndroidUtility
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import java.io.IOException
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList


@AndroidEntryPoint
class ProductDetails : AppCompatActivity() {

    private lateinit var binding : ActivityProductDetailsBinding
    var Transitionflag = AppConstants.transitionflagNext
    var product_id=0
    var shareurl:String?=""
    private val productViewModel by viewModels<ProductDetailsViewModel>()
    private val closeplayerViewModel by viewModels<CloseplayerViewModel>()
    var Similar_listdata: ArrayList<SimilarProduct>?= ArrayList()
    private var mMediaPlayer: MediaPlayer? = null
    private  var mSeekbarUpdateHandler: Handler?=null
    var mUpdateSeekbar: Runnable?=null

    var audioLink:ArrayList<String>?= ArrayList()
    var pos=0
    var playFlag=false
    var  Currentprogress: Int=0
    var  Maxprogress: Int=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_product_details)

        product_id=intent.getIntExtra(AppConstants.product_id, 0)

        audioLink!!.add("https://pagalfree.com/musics/128-Aankhon Ki Gustakhiyan - Hum Dil De Chuke Sanam 128 Kbps.mp3")
//        audioLink!!.add("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3")

        initView()
        Listener()
        getProductDetails()
    }

    fun initView(){

    }

    fun Listener(){
        binding.toolbarHeaderContent.ivBack.setOnClickListener {

            ClosePlayer()
        }

        binding.tvSimilarAudioBookViewmore.setOnClickListener {
            val intent = Intent(this@ProductDetails, CategoryList::class.java)
            intent.putExtra(AppConstants.header_title, getString(R.string.similarAudioBook))
            startActivity(intent)
        }


        binding.ivShare.setOnClickListener {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Hey check out " + getString(R.string.app_name) + " at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID
            )
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        }

       binding.seekbarAudio.setOnSeekBarChangeListener(object :
               SeekBar.OnSeekBarChangeListener {
           override fun onProgressChanged(seek: SeekBar,
                                          progress: Int, fromUser: Boolean) {
               Currentprogress = progress
               if (fromUser)
                   mMediaPlayer!!.seekTo(progress)
               val AudioprogressTime = String.format("%02d:%02d",
                       TimeUnit.MILLISECONDS.toMinutes(progress.toLong()),
                       TimeUnit.MILLISECONDS.toSeconds(progress.toLong()) -
                               TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(progress.toLong()))
               );
               binding.tvAudiocurrentTime.text = "" + AudioprogressTime
           }

           override fun onStartTrackingTouch(seek: SeekBar) {
               // write custom code for progress is started
           }

           override fun onStopTrackingTouch(seek: SeekBar) {
               // write custom code for progress is stopped
               /*  Toast.makeText(this@ProductDetails,
                       "Progress is: " + seek.progress + "%",
                       Toast.LENGTH_SHORT).show()*/
           }
       })

        binding.ivPreviousaudio.setOnClickListener {

            Log.d(getString(R.string.app_name), "Currentprogress: " + Currentprogress)
            Log.d(getString(R.string.app_name), "Maxprogress: " + Maxprogress)

            if(Currentprogress-10000>0){
                mMediaPlayer!!.seekTo(Currentprogress - 10000)
            }else{
                mMediaPlayer!!.seekTo(0)
            }
        }

        binding.ivNextaudio.setOnClickListener {


            Log.d(getString(R.string.app_name), "Currentprogress: " + Currentprogress)
            Log.d(getString(R.string.app_name), "Maxprogress: " + Maxprogress)

            if(Currentprogress+10000<Maxprogress){
                mMediaPlayer!!.seekTo(Currentprogress + 10000)
            }

        }

    }

    fun getProductDetails(){
        var device_type=device_type
        var device_token=Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN, "")
        val device_id = AndroidUtility.getAndroidDeviceId(this)

        val task = ProductDetailsBody(product_id, device_type, device_token, device_id)
        Log.d(getString(R.string.app_name), "" + Gson().toJson(task))

        binding.pbloader.visibility = View.VISIBLE

        productViewModel.fetchProductResponse(
                Prefs.with(this).read(
                        AppConstants.User_TOKEN,
                        AppConstants.Bearer_Value
                ), task
        )
        productViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "" + response.data.isSubscribed)
//                        binding.pbloader.visibility = View.GONE
                        Picasso.get()
                                .load(response.data.product!!.thumbnail)
                                .placeholder(R.drawable.ic_no_imagemotivation_one)
                                .error(R.drawable.ic_no_imagemotivation_one)
                                .into(binding.ivBannerDemo)

                        binding.tvTitle.text = response.data.product!!.name
                        binding.tvAuthorname.text = response.data.product!!.author
                        binding.tvNarratorname.text = response.data.product!!.narrator
                        binding.tvDesc.text = response.data.product!!.description

                        Similar_listdata = response.data.similarProduct
                        SetCatagoryView()

                        if (response.data.product!!.isFree == 1) {
                            PlayAudio(response.data.product!!.paidFile!!)
                        } else {


                            PlayAudio(response.data.product!!.promoFile!!)
                        }
//                        PlayAudio(audioLink!!.get(pos))

                    }

                }

                is NetworkResult.Error -> {

                    Log.d(getString(R.string.app_name) + ": ", response.message!!)
                    if (response.message!!.contains("500")) {
                        Toast.makeText(this, "Streaming is ongoing in other device", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
                    }

                    binding.pbloader.visibility = View.GONE
                    finish()
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }




    fun SetCatagoryView(){
        binding.llSimillar.removeAllViews()
        for(i in 0 until Similar_listdata!!.size){
            binding.llSimillar.addView(getHomeCategoryItemView(Similar_listdata!!.get(i)))
        }



    }


    private fun  getHomeCategoryItemView(catProduct: SimilarProduct): View? {

        val view: View =
            LayoutInflater.from(this).inflate(R.layout.adapter_calegory_list, null)
        val Iv_categoryname = view.findViewById<View>(R.id.iv_cl) as ImageView

        Picasso.get()
            .load(catProduct.thumbnail)
            .placeholder(R.drawable.ic_no_imagemotivation_one)
            .error(R.drawable.ic_no_imagemotivation_one)
            .into(Iv_categoryname)


        Iv_categoryname.setOnClickListener {
           /* val intent = Intent(this, ProductDetails::class.java)
            intent.putExtra(AppConstants.product_id,catProduct.id)
            startActivity(intent)
            finish()*/
            if (mMediaPlayer != null) {
                if (mMediaPlayer!!.isPlaying) {
                    mMediaPlayer!!.stop()
                }
                mSeekbarUpdateHandler!!.removeCallbacks(mUpdateSeekbar!!);
                mMediaPlayer!!.release()
                mMediaPlayer = null
            }


            product_id=catProduct.id!!
            getProductDetails()
        }


        return view
    }

    // ************ Audio File Play

    fun PlayAudio(urlpath: String){

        playFlag=true
        Log.d(getString(R.string.app_name), "url: " + urlpath)
        mMediaPlayer = MediaPlayer()
        mSeekbarUpdateHandler = Handler()

        if(urlpath.equals("")){
            binding.pbloader.visibility = View.GONE
            Toast.makeText(this, "Audio file not available", Toast.LENGTH_SHORT).show()
        }else {

            try {
                val myUri: Uri = Uri.parse(urlpath)
                mMediaPlayer!!.start()
                mMediaPlayer!!.setDataSource(this, myUri)
                mMediaPlayer!!.setAudioStreamType(AudioManager.STREAM_MUSIC)
                mMediaPlayer!!.isLooping
                mMediaPlayer!!.prepareAsync()

            } catch (e: IOException) {
                e.printStackTrace()
            }
            mMediaPlayer!!.setOnPreparedListener(OnPreparedListener {
                binding.pbloader.visibility = View.GONE

                togglePlayPause()
                binding.seekbarAudio.setMax(mMediaPlayer!!.getDuration());
                Maxprogress = mMediaPlayer!!.getDuration()

                val AudiomaxTime = String.format("%02d:%02d",
                        TimeUnit.MILLISECONDS.toMinutes(mMediaPlayer!!.getDuration().toLong()),
                        TimeUnit.MILLISECONDS.toSeconds(mMediaPlayer!!.getDuration().toLong()) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(mMediaPlayer!!.getDuration().toLong()))
                )
                binding.tvAudiomaxTime.text = "" + AudiomaxTime
            })

            binding.mPlayerControl.setOnClickListener(View.OnClickListener { togglePlayPause() })

            mMediaPlayer!!.setOnCompletionListener {

                binding.mPlayerControl.setImageResource(R.drawable.btn_play_audio_book_details)
                mMediaPlayer!!.seekTo(0)

            }

            mUpdateSeekbar = object : Runnable {
                override fun run() {
                    binding.seekbarAudio.setProgress(mMediaPlayer!!.currentPosition)
                    mSeekbarUpdateHandler!!.postDelayed(this, 50)
                }
            }
        }
    }

    private fun togglePlayPause() {
        if (mMediaPlayer!!.isPlaying) {
            mMediaPlayer!!.pause()
            binding.mPlayerControl.setImageResource(R.drawable.btn_play_audio_book_details)
            mSeekbarUpdateHandler!!.removeCallbacks(mUpdateSeekbar!!)
        } else {
            mMediaPlayer!!.start()
            binding.mPlayerControl.setImageResource(R.drawable.btn_pause_audio_book_details)
            mSeekbarUpdateHandler!!.postDelayed(mUpdateSeekbar!!, 0)
        }
    }



    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, Transitionflag) // Screen transition animation
    }

    override fun onDestroy() {
        super.onDestroy()
        ClosePlayer()

    }

    override fun onBackPressed() {
        ClosePlayer()
    }

    fun ClosePlayer(){
        var device_type= AppConstants.device_type
        var device_token=Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN, "")
        val device_id = AndroidUtility.getAndroidDeviceId(this)

        val task = LogoutBody(device_type, device_token, device_id)
        Log.d(getString(R.string.app_name), "" + Gson().toJson(task))
//        binding.pbloader.visibility = View.VISIBLE
        closeplayerViewModel.fetchcloseplayerResponse(task, Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        closeplayerViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        try {
                            if (mMediaPlayer != null) {
                                if (mMediaPlayer!!.isPlaying) {
                                    mMediaPlayer!!.stop()
                                }
                                mSeekbarUpdateHandler!!.removeCallbacks(mUpdateSeekbar!!);
                                mMediaPlayer!!.release()
                                mMediaPlayer = null
                            }
                            Transitionflag = AppConstants.transitionflagBack
                            finish()
                        } catch (e: Exception) {
                            Log.d(getString(R.string.app_name), "response" + e)

                        }


                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response.message)
                    binding.pbloader.visibility = View.GONE
                    try {
                        if (mMediaPlayer != null) {
                            if (mMediaPlayer!!.isPlaying) {
                                mMediaPlayer!!.stop()
                            }
                            mSeekbarUpdateHandler!!.removeCallbacks(mUpdateSeekbar!!);
                            mMediaPlayer!!.release()
                            mMediaPlayer = null
                        }
                        Transitionflag = AppConstants.transitionflagBack
                        finish()
                    } catch (e: Exception) {
                        Log.d(getString(R.string.app_name), "response" + e)

                    }
                }

                is NetworkResult.Loading -> {

                }
            }
        }
    }
}