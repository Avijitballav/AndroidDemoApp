package com.talki.booki.app.ui.notification

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.talki.booki.app.Model.HomeFilter
import com.talki.booki.app.Model.Notification.NotificationClass
import com.talki.booki.app.Model.NotificationBody
import com.talki.booki.app.Model.categorywiseProduct.CategorywiseProductClass
import com.talki.booki.app.data.remote.Repository
import com.talki.booki.app.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NotificationViewModel @Inject constructor
(
        private val repository: Repository,
        application: Application
) : AndroidViewModel(application) {

    private val _response: MutableLiveData<NetworkResult<NotificationClass>> = MutableLiveData()
    val response: LiveData<NetworkResult<NotificationClass>> = _response

    fun notificationListResponse(token:String,task: NotificationBody) = viewModelScope.launch {
        repository.getNotificationList(token,task).collect { values ->
            _response.value = values
        }
    }

}