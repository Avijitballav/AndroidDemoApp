package com.talki.booki.app.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.ui.home.HomeActivity
import com.talki.booki.app.ui.login.Login
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs

class Splash : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        Handler().postDelayed(
            {
                moveToSignUpActivity()
            }, 3000
        )
    }

    private fun moveToSignUpActivity() {

//        val intent = Intent(this, Otp::class.java)
//        startActivity(intent)
//        finish()
//        overridePendingTransition(0,0)
//

       /* val intent = Intent(this@Splash, Login::class.java)
        startActivity(intent)
        finish()*/
       if( Prefs.with(this).read(AppConstants.USER_DETAILS,"").equals("")){
            val intent = Intent(this@Splash, Login::class.java)
            startActivity(intent)
            finish()
        }else{
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }


    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, AppConstants.transitionflagNext) // Screen transition animation
    }

}