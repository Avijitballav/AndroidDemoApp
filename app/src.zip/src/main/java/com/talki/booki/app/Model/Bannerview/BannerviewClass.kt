package com.talki.booki.app.Model.Bannerview

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

class BannerviewClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("banner")
    @Expose
    var banner: ArrayList<Banner>? = null

    @SerializedName("pagination")
    @Expose
    var pagination: Pagination? = null
}