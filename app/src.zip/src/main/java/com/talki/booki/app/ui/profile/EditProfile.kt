package com.talki.booki.app.ui.profile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.CannedAccessControlList
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.nabinbhandari.android.permissions.PermissionHandler
import com.nabinbhandari.android.permissions.Permissions
import com.talki.booki.app.Model.Loginiew.LoginviewClass
import com.talki.booki.app.Model.S3credential.S3credentialClass
import com.talki.booki.app.Model.UpdateBody
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.core.AppConstants.ImagePath
import com.talki.booki.app.core.AppConstants.default_password
import com.talki.booki.app.databinding.ActivityEditProfileBinding
import com.talki.booki.app.utils.*
import com.theartofdev.edmodo.cropper.CropImage
import dagger.hilt.android.AndroidEntryPoint
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

@AndroidEntryPoint
class EditProfile : AppCompatActivity() {
    private lateinit var binding : ActivityEditProfileBinding
    var Transitionflag = AppConstants.transitionflagBack
    val gson = GsonBuilder().setPrettyPrinting().create()
    lateinit var userinfoModel: LoginviewClass
    private val s3ViewModel by viewModels<S3ViewModel>()
    private val updateViewModel by viewModels<UpdateViewModel>()
    lateinit var s3credentialClass: S3credentialClass

    private val storagePermissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    companion object {

        private val IMAGE_DIRECTORY = ImagePath
    }


    var filePath: String = ""
    var KEY = ""
    var SECRET = ""

    private var s3Client: AmazonS3Client? = null
    private var credentials: BasicAWSCredentials? = null

    var imageFile:String? = ""
    private val requestCodeCamera: Int = 101
    private val requestCodeGallery: Int = 102
    private lateinit var file: File

    private lateinit var imageUri: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_edit_profile)
        userinfoModel = gson.fromJson(Prefs.with(this).read(AppConstants.USER_DETAILS, ""), LoginviewClass::class.java)

        Log.d(getString(R.string.app_name), "" + userinfoModel.user!!.profile_img)
        Glide.with(this)
                .load(userinfoModel.user!!.profile_img)
                .placeholder(R.drawable.ic_no_imagemotivation_one)
                .error(R.drawable.ic_no_imagemotivation_one)
                .into(binding.ivProfileimage)

        binding.tvEmail.text=userinfoModel.user!!.email

        binding.tvMobile.text=userinfoModel.user!!.phone
        binding.tvName.setText(userinfoModel.user!!.name)

        if(userinfoModel.user!!.profile_img!=null) {
            imageFile = userinfoModel.user!!.profile_img!!
        }


        initView()
        Listener()
        fetchS3Data()
    }

    fun initView(){

    }

    fun Listener() {
        binding.toolbarHeaderContent.ivBack.setOnClickListener {
            Transitionflag= AppConstants.transitionflagBack
            finish()
        }

        binding.ivProfileimage.setOnClickListener {
            checkImagePermission()
        }

        binding.tvApply.setOnClickListener {

            if(binding.tvName.text.toString().trim().equals("")){
                AndroidUtility.showSnackBar(this@EditProfile, getString(R.string.Enter_name))
            }else{
                EditSubmit()
            }
        }

    }

    fun EditSubmit(){
        var email=userinfoModel.user!!.email
        var name=binding.tvName.text.toString()
        var phone=userinfoModel.user!!.phone
        var password=default_password
        var profile_img=imageFile


        val task = UpdateBody(email, name, phone, password, profile_img)
        Log.d(getString(R.string.app_name), "" + Gson().toJson(task))

        binding.pbloader.visibility = View.VISIBLE
        updateViewModel.fetchLoginResponse(task, Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        updateViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "" + response.data.token)
                        AndroidUtility.showSnackBar(this@EditProfile, getString(R.string.Successfully_Update))
                        val gson = GsonBuilder().setPrettyPrinting().create()
                        val userdetails: String? = gson.toJson(response.data)
                        Prefs.with(this).write(AppConstants.USER_DETAILS, userdetails!!)
                        Prefs.with(this).write(AppConstants.User_TOKEN, AppConstants.Bearer + response.data.token!!)
                        Transitionflag = AppConstants.transitionflagBack
                        finish()

                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                            this,
                            "Error",
                            Toast.LENGTH_SHORT
                    ).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }

    fun fetchS3Data(){
        binding.pbloader.visibility = View.VISIBLE
        s3ViewModel.fetchS3Response(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        s3ViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {

                        s3credentialClass = response.data

                        KEY = s3credentialClass.awsS3Key!!
                        SECRET = s3credentialClass.awsS3Secret!!

                        credentials = BasicAWSCredentials(KEY, SECRET)
                        s3Client = AmazonS3Client(credentials)

                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {

                }
            }
        }
    }

    private fun checkImagePermission() {
        checkStoragePermission(object : PermissionHandler() {
            override fun onGranted() {
                showImagePicker()
            }

        })

    }




    private fun showImagePicker() {
        CropImage.activity().setAspectRatio(1, 1)
                .start(this)
    }

    fun checkStoragePermission(permissionHandler: PermissionHandler) {
        val rationale = "Please provide Media permission to get access to photos"
        val options = Permissions.Options()
                .setRationaleDialogTitle("Info")
                .setSettingsDialogTitle("Warning")
        Permissions.check(this, storagePermissions, rationale, options, permissionHandler)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result = CropImage.getActivityResult(data)
            if (resultCode == Activity.RESULT_OK) {
                val contentURI = result.uri
                filePath = Helper.getPath(this, contentURI)
                setImage()
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                val error = result.error
            }
        }
    }

    private fun setImage() {
        try {

            binding.pbloader.visibility=View.VISIBLE
            val transferUtility = TransferUtility(s3Client, this)
            val transferObserver: TransferObserver = transferUtility.upload(s3credentialClass.awsBucket,
                    s3credentialClass.imagePathS3 + File(filePath!!).name,
                    File(filePath!!),
                    CannedAccessControlList.PublicRead
            )
            Log.d(getString(R.string.app_name), "" + s3credentialClass.aWSPath + s3credentialClass.imagePathS3 + File(filePath!!).name)
            transferObserver.setTransferListener(object : TransferListener {
                override fun onStateChanged(id: Int, state: TransferState) {
                    Log.d(getString(R.string.app_name), "" + state)
                    if (TransferState.COMPLETED == state) {
                        binding.pbloader.visibility = View.GONE
                        imageFile = s3credentialClass.aWSPath + s3credentialClass.imagePathS3 + File(filePath!!).name
                        AndroidUtility.showSnackBar(this@EditProfile, getString(R.string.upload_successfully))
                        Glide.with(this@EditProfile)
                                .load(imageFile)
                                .placeholder(R.drawable.ic_no_imagemotivation_one)
                                .error(R.drawable.ic_no_imagemotivation_one)
                                .into(binding.ivProfileimage)

                    } else if (TransferState.FAILED == state) {
                        binding.pbloader.visibility = View.GONE

                        AndroidUtility.showSnackBar(this@EditProfile, getString(R.string.upload_failed))
                    } else {
                        if (TransferState.IN_PROGRESS != state) {
                            binding.pbloader.visibility = View.GONE
                        }
                    }
                }

                override fun onProgressChanged(id: Int, bytesCurrent: Long, bytesTotal: Long) {
                    val percentDonef =
                            bytesCurrent.toFloat() / bytesTotal.toFloat() * 100
                    val percentDone = percentDonef.toInt()
                }

                override fun onError(id: Int, ex: java.lang.Exception) {
                    ex.printStackTrace()
                }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, Transitionflag) // Screen transition animation
    }
}