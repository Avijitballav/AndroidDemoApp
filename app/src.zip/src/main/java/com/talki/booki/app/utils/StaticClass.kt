package com.talki.booki.app.utils

/**
 * Created by abhijit on 01,Mar,2021.
 */
object StaticClass{
    var error="error"
    var success="success"

    const val USER_DETAILS= "user"



}