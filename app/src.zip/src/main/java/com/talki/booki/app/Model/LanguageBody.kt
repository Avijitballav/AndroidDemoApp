package com.talki.booki.app.Model

import java.util.*

class LanguageBody (private val email: String?,
                    private val login_type: String?,
                    private val name: String?,
                    private val phone: String?,
                    private val device_type: String?,
                    private val device_token: String?,
                    private val device_id: String?)


