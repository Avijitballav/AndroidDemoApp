package com.talki.booki.app.Model.getProfile

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class User {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("phone")
    @Expose
    var phone: Any? = null

    @SerializedName("login_type")
    @Expose
    var loginType: String? = null

    @SerializedName("is_active")
    @Expose
    var isActive: Int? = null

    @SerializedName("profile_img")
    @Expose
    var profileImg: String? = null
}