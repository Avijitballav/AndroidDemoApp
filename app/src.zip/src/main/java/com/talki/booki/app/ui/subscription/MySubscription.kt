package com.talki.booki.app.ui.subscription

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.talki.booki.app.Model.SubscriptionPackages.Package
import com.talki.booki.app.Model.categorywiseProduct.Category
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.core.AppConstants.PriceCurrency
import com.talki.booki.app.databinding.ActivityMySubscriptionBinding
import com.talki.booki.app.ui.category.CategoryListAdapter
import com.talki.booki.app.ui.home.CategorywiseProductViewModel
import com.talki.booki.app.ui.home.HomeActivity
import com.talki.booki.app.ui.payment.PaymentActivity
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class MySubscription : AppCompatActivity() {

    private lateinit var binding : ActivityMySubscriptionBinding
    var Transitionflag = AppConstants.transitionflagBack

    private val mysubscriptionViewModel by viewModels<MySubscriptionViewModel>()
    private val subscriptionpackagesViewModel by viewModels<SubscriptionPackagesViewModel>()

    private lateinit var mCategoryListAdapter: PackagesAdapter
    var layoutManager: LinearLayoutManager?=null
    var Subscription_listdata: ArrayList<Package>?= ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_subscription)

        initView()
        Listener()

    }

    override fun onResume() {
        super.onResume()
        fetchMySubscriptionData()
        fetchSubscriptionPackagesData()

    }


    fun initView(){


    }

    fun Listener(){
        binding.ivBack.setOnClickListener {
            Transitionflag= AppConstants.transitionflagBack
            finish()
        }

      /*  binding.llYearly.setOnClickListener {
            val intent = Intent(this@MySubscription, PaymentActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.llMonthly.setOnClickListener {
            val intent = Intent(this@MySubscription, PaymentActivity::class.java)
            startActivity(intent)
            finish()
        }*/

    }

    fun fetchMySubscriptionData(){
        binding.pbloader.visibility = View.VISIBLE
        mysubscriptionViewModel.fetchMySubscriptionResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        mysubscriptionViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(
                                getString(R.string.app_name),
                                "**********position**" + response.data.status
                        )

                      if(response.data.isSubscribed==1){

                          binding.tvCurentplan.visibility=View.VISIBLE
                          binding.tvCurentplanStart.visibility=View.VISIBLE
                          binding.tvCurentplanEnd.visibility=View.VISIBLE

                          binding.tvCurentplan.text=PriceCurrency+" "+response.data.mysubscriptionpackage!!.price
                          binding.tvCurentplanStart.text="Start Date: "+response.data.mysubscriptionpackage!!.startDate
                          binding.tvCurentplanEnd.text="End Date: "+response.data.mysubscriptionpackage!!.endDate
                      }
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                            this,
                            "Error" ,
                            Toast.LENGTH_SHORT
                    ).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }

    fun fetchSubscriptionPackagesData(){

        subscriptionpackagesViewModel.fetchSubscriptionPackagesResponse(Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        subscriptionpackagesViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(
                                getString(R.string.app_name),
                                "**********position**" + response.data.status
                        )
                        Subscription_listdata=response.data.packages
                        SetPackagesdata()
                    }

                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                            this,
                            "Error" ,
                            Toast.LENGTH_SHORT
                    ).show()

                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }

    fun SetPackagesdata(){
        mCategoryListAdapter= PackagesAdapter(this, Subscription_listdata!!)
        val categoryTopicListLayoutManager = binding.rvCTopicList.layoutManager as GridLayoutManager
        binding.rvCTopicList.layoutManager = categoryTopicListLayoutManager
        categoryTopicListLayoutManager.spanCount = 1
        binding.rvCTopicList.adapter = mCategoryListAdapter
    }

    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, Transitionflag)
    }
}