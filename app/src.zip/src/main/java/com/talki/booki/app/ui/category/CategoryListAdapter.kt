package com.talki.booki.app.ui.category

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.talki.booki.app.Model.categorywiseProduct.Category
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.AdapterCalegoryListBinding
import com.talki.booki.app.ui.productdetails.ProductDetails
import java.util.*


class CategoryListAdapter (val mContext: Context,val topic_listdata: ArrayList<Category>) :
    RecyclerView.Adapter<CategoryListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            AdapterCalegoryListBinding.inflate(
                LayoutInflater.from(mContext),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return topic_listdata.get(0).catProducts!!.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.onBind()
    }

    inner class ViewHolder(val binding: AdapterCalegoryListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun onBind() {
                Glide.with(mContext)
                    .load(topic_listdata.get(0).catProducts!!.get(adapterPosition).thumbnail)
                        .placeholder(R.drawable.ic_no_imagemotivation_one)
                    .error(R.drawable.ic_no_imagemotivation_one)
                    .into(binding.ivCl)

            binding.ivCl.setOnClickListener {
                val intent = Intent(mContext, ProductDetails::class.java)
                intent.putExtra(AppConstants.product_id,topic_listdata.get(0).catProducts!!.get(adapterPosition).id)
                mContext.startActivity(intent)
            }
        }
    }
}