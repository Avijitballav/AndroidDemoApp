package com.talki.booki.app.data.remote


import com.talki.booki.app.Model.*
import com.talki.booki.app.Model.Bannerview.BannerviewClass
import com.talki.booki.app.Model.CategoryList.CategoryListClass
import com.talki.booki.app.Model.Language.LanguageClass
import com.talki.booki.app.Model.Loginiew.LoginviewClass
import com.talki.booki.app.Model.Logout.LogoutClass
import com.talki.booki.app.Model.MySubscripton.MySubscriptonClass
import com.talki.booki.app.Model.Notification.NotificationClass
import com.talki.booki.app.Model.Productdetailsview.ProductdetailsClass
import com.talki.booki.app.Model.S3credential.S3credentialClass
import com.talki.booki.app.Model.SubscriptionPackages.SubscriptionPackagesClass
import com.talki.booki.app.Model.categorywiseProduct.CategorywiseProductClass
import com.talki.booki.app.Model.enquarySubmit.submitEnquiryClass
import com.talki.booki.app.Model.getProfile.getprofileClass
import com.talki.booki.app.core.ApiConstant
import com.talki.booki.app.core.ApiConstant.getNotification_URL
import com.talki.booki.app.core.ApiConstant.productList_URL
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    /* Product list With category*/
    @POST(productList_URL)
    @Headers("Content-Type:application/json")
    suspend fun getCategorywiseProductList(
            @Header("Authorization") token: String,
        @Body task: HomeFilter
    ): Response<CategorywiseProductClass>

    /* Banner Image*/
    @POST(ApiConstant.banner_URL)
    @Headers("Content-Type:application/json")
    suspend fun getBanner(
            @Header("Authorization") token: String
    ): Response<BannerviewClass>


    /* Language list */
    @POST(ApiConstant.language_list_URL)
    @Headers("Content-Type:application/json")
    suspend fun getLanguage(
        @Header("Authorization") token: String
    ): Response<LanguageClass>


    /* Language list */
    @POST(ApiConstant.login_URL)
    @Headers("Content-Type:application/json")
    suspend fun getLogin(
        @Body task: LanguageBody
    ): Response<LoginviewClass>


    /* Category list */
    @POST(ApiConstant.category_list_URL)
    @Headers("Content-Type:application/json")
    suspend fun getCategory(
            @Header("Authorization") token: String
    ): Response<CategoryListClass>


    /* Product details */
    @POST(ApiConstant.product_URL)
    @Headers("Content-Type:application/json")
    suspend fun getProductDetails(
        @Header("Authorization") token: String,
        @Body task: ProductDetailsBody
    ): Response<ProductdetailsClass>

    /* Category list */
    @POST(ApiConstant.myprofile_URL)
    @Headers("Content-Type:application/json")
    suspend fun getProfile(
            @Header("Authorization") token: String
    ): Response<getprofileClass>

    /* S3 Credential*/
    @GET(ApiConstant.gets3credential_URL)
    @Headers("Content-Type:application/json")
    suspend fun getS3(
        @Header("Authorization") token: String
    ): Response<S3credentialClass>


    /* Update */
    @POST(ApiConstant.updateprofile_URL)
    @Headers("Content-Type:application/json")
    suspend fun getUpdate(
        @Body task: UpdateBody,
        @Header("Authorization") token: String
    ): Response<LoginviewClass>

    /* Category list */
    @POST(ApiConstant.mysubscription_URL)
    @Headers("Content-Type:application/json")
    suspend fun getMySubscription(
            @Header("Authorization") token: String
    ): Response<MySubscriptonClass>

    /* subscriptionpackages list */
    @POST(ApiConstant.subscriptionpackages_URL)
    @Headers("Content-Type:application/json")
    suspend fun getSubscriptionPackage(
            @Header("Authorization") token: String
    ): Response<SubscriptionPackagesClass>


    /* Logout */
    @POST(ApiConstant.logout_URL)
    @Headers("Content-Type:application/json")
    suspend fun getLogout(
            @Body task: LogoutBody,
            @Header("Authorization") token: String
    ): Response<LogoutClass>

    /* Logout */
    @POST(ApiConstant.closeplayer_URL)
    @Headers("Content-Type:application/json")
    suspend fun getClosePlayer(
        @Body task: LogoutBody,
        @Header("Authorization") token: String
    ): Response<LogoutClass>

    /* Help and Suport */
    @POST(ApiConstant.submitEnquiry_URL)
    @Headers("Content-Type:application/json")
    suspend fun getHelp(
        @Body task: HelpSupportBody,
        @Header("Authorization") token: String
    ): Response<submitEnquiryClass>


    /* Notification list */
    @POST(getNotification_URL)
    @Headers("Content-Type:application/json")
    suspend fun getNotificationList(
            @Header("Authorization") token: String,
            @Body task: NotificationBody
    ): Response<NotificationClass>

}
