package com.talki.booki.app.Model.SubscriptionPackages

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Package {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("package_name")
    @Expose
    var packageName: String? = null

    @SerializedName("slug")
    @Expose
    var slug: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("price")
    @Expose
    var price: Int? = null

    @SerializedName("validity")
    @Expose
    var validity: Int? = null

    @SerializedName("is_active")
    @Expose
    var isActive: Int? = null

    @SerializedName("is_deleted")
    @Expose
    var isDeleted: Int? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: Int? = null

    @SerializedName("updated_by")
    @Expose
    var updatedBy: Int? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null
}