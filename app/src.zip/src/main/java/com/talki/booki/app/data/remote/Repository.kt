package com.talki.booki.app.data.remote



import com.talki.booki.app.Model.*
import com.talki.booki.app.Model.Bannerview.BannerviewClass
import com.talki.booki.app.Model.CategoryList.CategoryListClass
import com.talki.booki.app.Model.Language.LanguageClass
import com.talki.booki.app.Model.Loginiew.LoginviewClass
import com.talki.booki.app.Model.Logout.LogoutClass
import com.talki.booki.app.Model.MySubscripton.MySubscriptonClass
import com.talki.booki.app.Model.Notification.NotificationClass
import com.talki.booki.app.Model.Productdetailsview.ProductdetailsClass
import com.talki.booki.app.Model.S3credential.S3credentialClass
import com.talki.booki.app.Model.SubscriptionPackages.SubscriptionPackagesClass
import com.talki.booki.app.Model.categorywiseProduct.CategorywiseProductClass
import com.talki.booki.app.Model.enquarySubmit.submitEnquiryClass
import com.talki.booki.app.Model.getProfile.getprofileClass
import com.talki.booki.app.utils.NetworkResult
import dagger.hilt.android.scopes.ActivityRetainedScoped
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject


@ActivityRetainedScoped
class Repository @Inject constructor(
    private val remoteDataSource: RemoteDataSource
) : BaseApiResponse() {

    suspend fun getCategoryList(token:String,task:HomeFilter): Flow<NetworkResult<CategorywiseProductClass>> {
        return flow<NetworkResult<CategorywiseProductClass>> {
            emit(safeApiCall { remoteDataSource.getCategorywiseProductList(token,task) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getBanner(token:String): Flow<NetworkResult<BannerviewClass>> {
        return flow<NetworkResult<BannerviewClass>> {
            emit(safeApiCall { remoteDataSource.getBanner(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getLanguage(token:String): Flow<NetworkResult<LanguageClass>> {
        return flow<NetworkResult<LanguageClass>> {
            emit(safeApiCall { remoteDataSource.getLanguage(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getLogin(task: LanguageBody): Flow<NetworkResult<LoginviewClass>> {
        return flow<NetworkResult<LoginviewClass>> {
            emit(safeApiCall { remoteDataSource.getLogin(task) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getCategory(token:String): Flow<NetworkResult<CategoryListClass>> {
        return flow<NetworkResult<CategoryListClass>> {
            emit(safeApiCall { remoteDataSource.getCategory(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getproductDetails(token:String,task: ProductDetailsBody): Flow<NetworkResult<ProductdetailsClass>> {
        return flow<NetworkResult<ProductdetailsClass>> {
            emit(safeApiCall { remoteDataSource.getProductDetails(token,task) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getProfile(token:String): Flow<NetworkResult<getprofileClass>> {
        return flow<NetworkResult<getprofileClass>> {
            emit(safeApiCall { remoteDataSource.getProfile(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getS3(token:String): Flow<NetworkResult<S3credentialClass>> {
        return flow<NetworkResult<S3credentialClass>> {
            emit(safeApiCall { remoteDataSource.getS3(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getUpdate(task: UpdateBody,token:String): Flow<NetworkResult<LoginviewClass>> {
        return flow<NetworkResult<LoginviewClass>> {
            emit(safeApiCall { remoteDataSource.getUpdate(task,token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getMySubscription(token:String): Flow<NetworkResult<MySubscriptonClass>> {
        return flow<NetworkResult<MySubscriptonClass>> {
            emit(safeApiCall { remoteDataSource.getMySubscription(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getSubscriptionPackage(token:String): Flow<NetworkResult<SubscriptionPackagesClass>> {
        return flow<NetworkResult<SubscriptionPackagesClass>> {
            emit(safeApiCall { remoteDataSource.getSubscriptionPackage(token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getLogout(task: LogoutBody,token:String): Flow<NetworkResult<LogoutClass>> {
        return flow<NetworkResult<LogoutClass>> {
            emit(safeApiCall { remoteDataSource.getLogout(task,token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getClosePlayer(task: LogoutBody,token:String): Flow<NetworkResult<LogoutClass>> {
        return flow<NetworkResult<LogoutClass>> {
            emit(safeApiCall { remoteDataSource.getClosePlayer(task,token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getHelp(task: HelpSupportBody,token:String): Flow<NetworkResult<submitEnquiryClass>> {
        return flow<NetworkResult<submitEnquiryClass>> {
            emit(safeApiCall { remoteDataSource.getHelp(task,token) })
        }.flowOn(Dispatchers.IO)
    }

    suspend fun getNotificationList(token:String,task:NotificationBody): Flow<NetworkResult<NotificationClass>> {
        return flow<NetworkResult<NotificationClass>> {
            emit(safeApiCall { remoteDataSource.getNotificationList(token,task) })
        }.flowOn(Dispatchers.IO)
    }
}
