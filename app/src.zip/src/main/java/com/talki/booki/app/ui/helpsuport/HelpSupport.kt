package com.talki.booki.app.ui.helpsuport

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.talki.booki.app.Model.HelpSupportBody
import com.talki.booki.app.Model.Loginiew.LoginviewClass
import com.talki.booki.app.Model.UpdateBody
import com.talki.booki.app.R
import com.talki.booki.app.addview.BottomviewContent
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.databinding.ActivityHelpSupportBinding
import com.talki.booki.app.databinding.ActivityHomeBinding
import com.talki.booki.app.ui.notification.Notifications
import com.talki.booki.app.ui.profile.MyProfile
import com.talki.booki.app.ui.profile.UpdateViewModel
import com.talki.booki.app.utils.AndroidUtility
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HelpSupport : AppCompatActivity() {

    private lateinit var binding : ActivityHelpSupportBinding
    lateinit var userinfoModel: LoginviewClass
    val gson = GsonBuilder().setPrettyPrinting().create()

    private val helpViewModel by viewModels<HelpSuportViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_help_support)
        userinfoModel = gson.fromJson(Prefs.with(this).read(AppConstants.USER_DETAILS, ""), LoginviewClass::class.java)


        initView()
        Listener()
    }

    fun initView(){
        binding.tvUseremail.text=userinfoModel.user!!.email

        if(userinfoModel.user!!.name!=null)
         binding.tvName.text= Editable.Factory.getInstance().newEditable(userinfoModel.user!!.name)

        if(userinfoModel.user!!.phone!=null)
         binding.tvMobile.text= Editable.Factory.getInstance().newEditable(userinfoModel.user!!.phone)

    }

    fun Listener(){
        binding.tvBottomHome.setOnClickListener {
            finish()

        }

        binding.tvBottomNotification.setOnClickListener {
            val intent = Intent(this@HelpSupport, Notifications::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvBottomAccount.setOnClickListener {
            val intent = Intent(this@HelpSupport, MyProfile::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvApply.setOnClickListener {
            if(binding.tvMobile.text.toString().trim().equals("")){
                AndroidUtility.showSnackBar(this@HelpSupport, getString(R.string.Enter_phone))
            }else if(binding.tvName.text.toString().trim().equals("")){
                AndroidUtility.showSnackBar(this@HelpSupport, getString(R.string.Enter_name))
            }else if(binding.tvTypeYourMessageHere.text.toString().trim().equals("")){
                AndroidUtility.showSnackBar(this@HelpSupport, getString(R.string.Enter_comment))
            }else{
                SupportSubmit()
            }
        }

        binding.tvExploreAudioBook.setOnClickListener {
            finish()
        }
    }

    fun SupportSubmit(){
        var email=userinfoModel.user!!.email
        var name=binding.tvName.text.toString()
        var phone=userinfoModel.user!!.phone.toString()
        var comment= binding.tvTypeYourMessageHere.text.toString()



        val task = HelpSupportBody(email, name, phone, comment)
        Log.d(getString(R.string.app_name), "" + Gson().toJson(task))

        binding.pbloader.visibility = View.VISIBLE
        helpViewModel.helpsupportResponse(task, Prefs.with(this).read(AppConstants.User_TOKEN, AppConstants.Bearer_Value))
        helpViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {

                        binding.rlMain.visibility=View.GONE
                        binding.rlThankyou.visibility=View.VISIBLE
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this,
                        "Error",
                        Toast.LENGTH_SHORT
                    ).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }
}