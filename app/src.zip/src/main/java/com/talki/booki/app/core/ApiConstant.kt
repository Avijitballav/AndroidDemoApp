package com.talki.booki.app.core

object ApiConstant {


    const val Youtube_URL = "https://www.youtube.com/watch?v="

    const val Blog_URL = "http://13.234.17.21:5000/api/utility/"

//    const val BASE_URL = "http://localhost:5048/api/v1/front/"
//    const val BASE_URL = "https://rickandmortyapi.com/api/"
    const val BASE_URL_Type = "Local"

    //    const val BASE_URL_Type = "Live"

    const val BASE_URL = "http://demoyourprojects.com:5048/api/v1/front/"
    const val categoryList_URL = "category/list"
    const val productList_URL = "product/list"
    const val banner_URL = "banner"
    const val language_list_URL = "language/list"
    const val login_URL = "login"
    const val category_list_URL = "category/list"
    const val product_URL = "product"
    const val myprofile_URL = "myprofile"
    const val gets3credential_URL = "gets3credential"
    const val updateprofile_URL = "updateprofile"
    const val mysubscription_URL = "subscription/mysubscription"
    const val subscriptionpackages_URL = "subscription/packages"
    const val logout_URL = "logout"
    const val closeplayer_URL = "closeplayer"
    const val submitEnquiry_URL = "submitEnquiry"
    const val getNotification_URL = "getNotification"



}