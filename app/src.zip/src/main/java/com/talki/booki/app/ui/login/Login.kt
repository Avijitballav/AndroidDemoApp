package com.talki.booki.app.ui.login

import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64.DEFAULT
import android.util.Base64.encodeToString
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.facebook.CallbackManager
import com.facebook.login.LoginManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.talki.booki.app.Model.HomeFilter
import com.talki.booki.app.Model.LanguageBody
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.core.AppConstants.Bearer
import com.talki.booki.app.core.AppConstants.Bearer_Value
import com.talki.booki.app.databinding.ActivityLoginBinding
import com.talki.booki.app.ui.home.HomeActivity
import com.talki.booki.app.ui.home.LanguageViewModel
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.OnPauseSlider
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*


import android.util.Base64
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginResult
import com.talki.booki.app.core.AppConstants.login_type_fb
import com.talki.booki.app.core.AppConstants.login_type_g
import com.talki.booki.app.utils.AndroidUtility

@AndroidEntryPoint
class Login : AppCompatActivity() {
    private lateinit var binding : ActivityLoginBinding
    private val loginViewModel by viewModels<LoginViewModel>()
    private lateinit var fbCallbackManager: CallbackManager
    private lateinit var fbLoginManager: LoginManager
    private val readFBContentEmail: String = "email"
    private var login_type=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)

        initVariable()
        initListeners()
        //printHashKey()


    }

    public override fun onPause() {
        super.onPause()
        OnPauseSlider(this, AppConstants.transitionflagNext) // Screen transition animation
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        fbCallbackManager.onActivityResult(requestCode, resultCode, data)
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun initVariable() {
        fbCallbackManager = CallbackManager.Factory.create()
        fbLoginManager = LoginManager.getInstance()
    }

    private fun initListeners() {
        binding.ivFacebooklogin.setOnClickListener {
            if( Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN,"").equals("")) {
                Toast.makeText(
                    this,
                    "Please wait.." ,
                    Toast.LENGTH_SHORT
                ).show()
            }else{
                login_type= login_type_fb
//                fbLoginClickHandler()
                LoginSubmit()
            }
        }

        binding.ivGooglelogin.setOnClickListener {
            if( Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN,"").equals("")) {
                Toast.makeText(
                    this,
                    "Please wait.." ,
                    Toast.LENGTH_SHORT
                ).show()
            }else{
                login_type= login_type_g
                LoginSubmit()
            }

        }

    }

    /**
     * Print HashKey For
     * Facebook-Android Sign In
     * Integration
     */
    private fun printHashKey() {
        try {
            val info = packageManager.getPackageInfo(
                "com.talki.booki.app",
                PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {

        } catch (e: Exception) {

        }
    }

    /**
     * Click Handler
     */
    private fun fbLoginClickHandler() {
        fbLoginManager.logInWithReadPermissions(this@Login, listOf(readFBContentEmail))
        fbLoginManager.registerCallback(fbCallbackManager, object : FacebookCallback<LoginResult> {
            override fun onCancel() {
                Log.e(getString(R.string.app_name), "FB onCancel Callback")
            }

            override fun onError(error: FacebookException) {
                Log.e(getString(R.string.app_name), "${error?.message}")
            }

            override fun onSuccess(result: LoginResult) {
                result?.let { fbLoginResult ->
                    Log.e(getString(R.string.app_name), "FB ACCESS TOKEN: ${fbLoginResult.accessToken}")

                    LoginSubmit()
                }
            }

        })
    }



/*
    {
        "email":"nora1@gmail.com",
        "login_type":"fb",
        "name":"Isha",
        "phone":"",
        "device_type":"ios",
        "device_token":"123456"
    }
*/

    fun LoginSubmit(){

        var email="avi123@gmail.com"
        var login_type=login_type
        var name="Avi"
        var phone=""
        var device_type= AppConstants.device_type
        var device_token=Prefs.with(baseContext.applicationContext).read(AppConstants.DEVICE_TOKEN,"")
        val device_id = AndroidUtility.getAndroidDeviceId(this)

        val task = LanguageBody(email, login_type, name,phone,device_type,device_token,device_id)
        Log.d(getString(R.string.app_name), "" + Gson().toJson(task))
        binding.pbloader.visibility = View.VISIBLE
        loginViewModel.fetchLoginResponse(task)
        loginViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "" + response.data.token)
                        val gson = GsonBuilder().setPrettyPrinting().create()
                        val userdetails: String? = gson.toJson(response.data)
                        Prefs.with(this).write(AppConstants.USER_DETAILS, userdetails!!)
                        Prefs.with(this).write(AppConstants.User_TOKEN,Bearer+response.data.token!!)

                        val intent = Intent(this@Login, HomeActivity::class.java)
                        startActivity(intent)
                        finish()

                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this,
                        "Error" ,
                        Toast.LENGTH_SHORT
                    ).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }
}