package com.talki.booki.app.Model

class NotificationBody (private val device_type: String?,
                        private val device_token: String?,
                        private val device_id: String?)