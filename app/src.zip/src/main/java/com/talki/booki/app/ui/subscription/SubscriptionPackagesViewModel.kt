package com.talki.booki.app.ui.subscription

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.talki.booki.app.Model.MySubscripton.MySubscriptonClass
import com.talki.booki.app.Model.SubscriptionPackages.SubscriptionPackagesClass
import com.talki.booki.app.data.remote.Repository
import com.talki.booki.app.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SubscriptionPackagesViewModel  @Inject constructor
(
        private val repository: Repository,
        application: Application
) : AndroidViewModel(application) {

    private val _response: MutableLiveData<NetworkResult<SubscriptionPackagesClass>> = MutableLiveData()
    val response: LiveData<NetworkResult<SubscriptionPackagesClass>> = _response

    fun fetchSubscriptionPackagesResponse(token:String) = viewModelScope.launch {
        repository.getSubscriptionPackage(token).collect { values ->
            _response.value = values
        }
    }

}