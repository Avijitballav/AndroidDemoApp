package com.talki.booki.app.ui.home


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import com.talki.booki.app.Model.Bannerview.Banner
import com.talki.booki.app.Model.HomeFilter
import com.talki.booki.app.Model.Language.Language
import com.talki.booki.app.Model.categorywiseProduct.CatProduct
import com.talki.booki.app.Model.categorywiseProduct.Category
import com.talki.booki.app.R
import com.talki.booki.app.core.AppConstants
import com.talki.booki.app.core.AppConstants.Bearer_Value
import com.talki.booki.app.core.AppConstants.product_id
import com.talki.booki.app.databinding.ActivityHomeBinding
import com.talki.booki.app.ui.category.CategoryList
import com.talki.booki.app.ui.filter.Filter
import com.talki.booki.app.ui.helpsuport.HelpSupport
import com.talki.booki.app.ui.notification.Notifications
import com.talki.booki.app.ui.productdetails.ProductDetails
import com.talki.booki.app.ui.profile.MyProfile
import com.talki.booki.app.utils.NetworkResult
import com.talki.booki.app.utils.Prefs
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.language_bottom_sheet_dialog.view.*
import org.json.JSONObject
import java.io.Serializable
import java.util.*


@AndroidEntryPoint
class HomeActivity : AppCompatActivity() {
    private lateinit var binding : ActivityHomeBinding

    var languageFlag=true;
    private val mainViewModel by viewModels<CategorywiseProductViewModel>()
    private val bannerViewModel by viewModels<BannerViewModel>()
    private val languageViewModel by viewModels<LanguageViewModel>()

    var Category_listdata:ArrayList<Category>?= ArrayList()
    var Baner_listdata:ArrayList<Banner>?= ArrayList()
    var Language_listdata:ArrayList<Language>?= ArrayList()

    var category: ArrayList<String> = ArrayList()
    var language: ArrayList<String> = ArrayList()
    var is_free="";
    var languageList: ArrayList<Boolean> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home)

        Log.d(getString(R.string.app_name), "**********Token**" + Prefs.with(this).read(AppConstants.User_TOKEN,Bearer_Value))
        Listener()
        fetchBannerData()
        fetchcategoryData()
        fetchLanguageData()


    }

    fun fetchBannerData(){
        bannerViewModel.fetchBannerResponse( Prefs.with(this).read(AppConstants.User_TOKEN,Bearer_Value))
        bannerViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(
                            getString(R.string.app_name),
                            "**********position**" + response.data.status
                        )

                        Baner_listdata = response.data.banner
                        BanerView()
                    }
//                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)
                    Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
//                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {
//                    binding.pbloader.visibility = View.VISIBLE

                }
            }
        }
    }
    

    private fun fetchcategoryData() {

        val task = HomeFilter(category, language, is_free)
        Log.d(getString(R.string.app_name), "*********task***" + Gson().toJson(task));

        binding.pbloader.visibility = View.VISIBLE
        mainViewModel.fetchCategotyListResponse(Prefs.with(this).read(AppConstants.User_TOKEN,Bearer_Value), task)
        mainViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(
                            getString(R.string.app_name),
                            "**********position**" + response.data.status
                        )
                        Category_listdata= ArrayList()
                        Category_listdata = response.data.category

                        SetCatagoryView()
                    }
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this,
                        "" + response!!.data!!.messgae,
                        Toast.LENGTH_SHORT
                    ).show()
                    binding.pbloader.visibility = View.GONE
                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }

    fun fetchLanguageData(){
        languageViewModel.fetchLanguageResponse(Prefs.with(this).read(AppConstants.User_TOKEN,Bearer_Value))
        languageViewModel.response.observe(this) { response ->
            Log.d(getString(R.string.app_name), Gson().toJson(response.data))
            when (response) {
                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(getString(R.string.app_name), "**********position**" + response.data.status)

                        Language_listdata = response.data.language
                        for(i in 0 until Language_listdata!!.size){
                            languageList.add(false)
                        }

                    }

                }

                is NetworkResult.Error -> {
                    Log.d(getString(R.string.app_name), "response" + response)

                }

                is NetworkResult.Loading -> {


                }
            }
        }
    }


    fun SetLanguageView(){
        binding.includeLanguage.llLanguageview.removeAllViews()
        for(i in 0 until Language_listdata!!.size){
            binding.includeLanguage.llLanguageview.addView(getLanguageView(i))
        }
    }

    private fun  getLanguageView(position: Int): View? {
        val view: View =
                LayoutInflater.from(this).inflate(R.layout.language_cell_view, null)
        val tv_english = view.findViewById<View>(R.id.tv_english) as TextView

        if(languageList.get(position)){
            tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_selct),  null);
        }else{
            tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_dselct), null );
        }
        tv_english.setText(Language_listdata!!.get(position).name)

        tv_english.setOnClickListener {

            if(languageList.get(position)){
                languageList.set(position,false)
                tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_dselct),  null);
            }else{
                languageList.set(position,true)
                tv_english.setCompoundDrawablesWithIntrinsicBounds(null, null, getDrawable(R.drawable.ic_choose_language_selct), null );
            }


        }


        return view
    }

    fun SetCatagoryView(){
        binding.llMotivation.removeAllViews()
        for(i in 0 until Category_listdata!!.size){
            binding.llMotivation.addView(getHomeCategoryView(i))
        }

    }

    private fun  getHomeCategoryView(position: Int): View? {

        val view: View =
                LayoutInflater.from(this).inflate(R.layout.categoryview_inflate, null)
        val tv_categoryname = view.findViewById<View>(R.id.tv_categoryname) as TextView
        val tv_BestInMotivation_viewmore = view.findViewById<View>(R.id.tv_BestInMotivation_viewmore) as TextView
        val rv_categorylist= view.findViewById<View>(R.id.rv_categorylist) as LinearLayout

        tv_categoryname.setText(Category_listdata!!.get(position).name)

        tv_BestInMotivation_viewmore.setOnClickListener {
            val intent = Intent(this@HomeActivity, CategoryList::class.java)
            intent.putExtra(AppConstants.header_title, Category_listdata!!.get(position).name)
            intent.putExtra(AppConstants.category_Id, Category_listdata!!.get(position).id.toString())
            intent.putExtra(AppConstants.language_Id,  language as Serializable?)
            intent.putExtra(AppConstants.is_free_Id, is_free)

            startActivity(intent)
        }
        for(j in 0 until Category_listdata!!.get(position).catProducts!!.size) {
            rv_categorylist.addView(
                getHomeCategoryItemView(
                    Category_listdata!!.get(position).catProducts!!.get(
                        j
                    )
                )
            )
        }

        return view
    }

    private fun  getHomeCategoryItemView(catProduct: CatProduct): View? {

        val view: View =
                LayoutInflater.from(this).inflate(R.layout.adapter_calegory_list, null)
        val Iv_categoryname = view.findViewById<View>(R.id.iv_cl) as ImageView

        Picasso.get()
                .load(catProduct.thumbnail)
                .placeholder(R.drawable.ic_no_imagemotivation_one)
                .error(R.drawable.ic_no_imagemotivation_one)
                .into(Iv_categoryname)


        Iv_categoryname.setOnClickListener {
            val intent = Intent(this@HomeActivity, ProductDetails::class.java)
            intent.putExtra(product_id,catProduct.id)
            startActivity(intent)
        }


        return view
    }


    fun BanerView(){
        val adapter = MySliderImageAdapter()
        adapter.renewItems(Baner_listdata!!)
        binding.imageSlider.setSliderAdapter(adapter)
        binding.imageSlider.isAutoCycle = true
        binding.imageSlider.startAutoCycle()
    }

    fun Listener(){
        binding.toolbarheader.ivLanguage.setOnClickListener {

            if(languageFlag){
                languageFlag=false
                binding.rlLanguage.visibility=View.VISIBLE
                binding.scMain.visibility=View.GONE
                SetLanguageView()
            }else{
                languageFlag=true
                binding.rlLanguage.visibility=View.GONE
                binding.scMain.visibility=View.VISIBLE

                language= ArrayList()
                for(i in 0 until languageList!!.size){
                    if(languageList.get(i)){
                        language.add(Language_listdata!!.get(i).id.toString())
                    }
                }
                fetchcategoryData()
            }
        }

        binding.includeLanguage.tvNext.setOnClickListener {
            languageFlag=true
            binding.rlLanguage.visibility=View.GONE
            binding.scMain.visibility=View.VISIBLE

            language= ArrayList()
            for(i in 0 until languageList!!.size){
                if(languageList.get(i)){
                    language.add(Language_listdata!!.get(i).id.toString())
                }

            }
            fetchcategoryData()
        }

        binding.toolbarheader.ivNavigationIcon.setOnClickListener {
            languageFlag=true
            binding.rlLanguage.visibility=View.GONE
            binding.scMain.visibility=View.VISIBLE
            val intent = Intent(this@HomeActivity, Filter::class.java)

            intent.putExtra(AppConstants.category_Id, category as Serializable?)
            intent.putExtra(AppConstants.language_Id,  language as Serializable?)
            intent.putExtra(AppConstants.language_IdFlag,  languageList as Serializable?)
            intent.putExtra(AppConstants.is_free_Id, is_free)

            resultLauncher.launch(intent)
        }



        binding.tvBottomHelp.setOnClickListener {
            val intent = Intent(this@HomeActivity, HelpSupport::class.java)
            startActivity(intent)
        }

        binding.tvBottomNotification.setOnClickListener {
            val intent = Intent(this@HomeActivity, Notifications::class.java)
            startActivity(intent)
        }

        binding.tvBottomAccount.setOnClickListener {
            val intent = Intent(this@HomeActivity, MyProfile::class.java)
            startActivity(intent)
        }
    }

    var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        Log.d(getString(R.string.app_name), ""+result.resultCode)
        if (result.resultCode == Activity.RESULT_OK) {
            // There are no request codes
            val intent: Intent? = result.data
            Log.d(getString(R.string.app_name), Gson().toJson(intent))

            category=intent!!.getSerializableExtra(AppConstants.category_Id)  as ArrayList<String>
            language= intent.getSerializableExtra(AppConstants.language_Id) as ArrayList<String>
            languageList= intent.getSerializableExtra(AppConstants.language_IdFlag) as ArrayList<Boolean>
            is_free=intent.getStringExtra(AppConstants.is_free_Id)!!

            language= ArrayList()
            for(i in 0 until languageList!!.size){
                if(languageList.get(i)){
                    language.add(Language_listdata!!.get(i).id.toString())
                }

            }
         fetchcategoryData()
        }
    }


    override fun onBackPressed() {

        if(languageFlag){
            finish()
        }else{
            languageFlag=true
            binding.rlLanguage.visibility=View.GONE
            binding.scMain.visibility=View.VISIBLE
        }
    }




}