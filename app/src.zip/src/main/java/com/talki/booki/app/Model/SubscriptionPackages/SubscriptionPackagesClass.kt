package com.talki.booki.app.Model.SubscriptionPackages

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SubscriptionPackagesClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("packages")
    @Expose
    var packages: ArrayList<Package>? = null

    @SerializedName("pagination")
    @Expose
    var pagination: Pagination? = null
}