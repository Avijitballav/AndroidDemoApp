package com.talki.booki.app.Model.categorywiseProduct

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

class CategorywiseProductClass {
    @SerializedName("status")
    @Expose
    var status: Int? = null

    @SerializedName("messgae")
    @Expose
    var messgae: String? = null

    @SerializedName("error_code")
    @Expose
    var error_code: String? = null

    @SerializedName("category")
    @Expose
    var category: ArrayList<Category>? = null

    @SerializedName("pagination")
    @Expose
    var pagination: Pagination? = null
}