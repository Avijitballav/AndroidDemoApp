package com.talki.booki.app.data.remote

import com.talki.booki.app.Model.*
import org.json.JSONObject
import javax.inject.Inject

class RemoteDataSource @Inject constructor(
        private val categorywiseProductService: ApiService,
      ) {

    /* Product list With category*/
    suspend fun getCategorywiseProductList(token:String,task: HomeFilter) =
            categorywiseProductService.getCategorywiseProductList(token,task)

    /* Banner Image*/
    suspend fun getBanner(token:String) =
            categorywiseProductService.getBanner(token)

    /* Language list*/
    suspend fun getLanguage(token:String) =
        categorywiseProductService.getLanguage(token)

    /* Login */
    suspend fun getLogin(task:LanguageBody) =
        categorywiseProductService.getLogin(task)

    /* Category List*/
    suspend fun getCategory(token:String) =
            categorywiseProductService.getCategory(token)

    /* product Details */
    suspend fun getProductDetails(token:String,task: ProductDetailsBody) =
        categorywiseProductService.getProductDetails(token,task)

    /* Get Profile*/
    suspend fun getProfile(token:String) =
            categorywiseProductService.getProfile(token)

    /* Get Profile*/
    suspend fun getS3(token:String) =
        categorywiseProductService.getS3(token)

    /* Update */
    suspend fun getUpdate(task:UpdateBody,token:String) =
        categorywiseProductService.getUpdate(task,token)

    /* Get MyScription*/
    suspend fun getMySubscription(token:String) =
            categorywiseProductService.getMySubscription(token)

    /* Get Scription Packages*/
    suspend fun getSubscriptionPackage(token:String) =
            categorywiseProductService.getSubscriptionPackage(token)

    /* Logout */
    suspend fun getLogout(task: LogoutBody, token:String) =
            categorywiseProductService.getLogout(task,token)

    /* ClosePlayer */
    suspend fun getClosePlayer(task: LogoutBody, token:String) =
        categorywiseProductService.getClosePlayer(task,token)

    /* Help and Suport */
    suspend fun getHelp(task:HelpSupportBody,token:String) =
        categorywiseProductService.getHelp(task,token)

    /* Notification list */
    suspend fun getNotificationList(token:String,task: NotificationBody) =
            categorywiseProductService.getNotificationList(token,task)

}