package com.talki.booki.app.ui.notification

import android.content.Context
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.talki.booki.app.Model.Notification.Notification
import com.talki.booki.app.databinding.NotificationInflateBinding
import com.talki.booki.app.utils.AndroidUtility.Companion.convertDateFormat
import com.talki.booki.app.utils.AndroidUtility.Companion.formatDateFromString
import java.text.SimpleDateFormat
import java.util.*


class NotificationAdapter(val mContext: Context, val Notification_listdata: ArrayList<Notification>) :
        RecyclerView.Adapter<NotificationAdapter.ViewHolder>() {




    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
                NotificationInflateBinding.inflate(
                        LayoutInflater.from(mContext),
                        parent,
                        false
                )
        )
    }

    override fun getItemCount(): Int {
        return Notification_listdata.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.onBind()
    }

    inner class ViewHolder(val binding: NotificationInflateBinding) :
            RecyclerView.ViewHolder(binding.root) {

        fun onBind() {
            binding.tvSubjectTitle.text=Notification_listdata.get(adapterPosition).title
            binding.tvSubjectdes.text=Notification_listdata.get(adapterPosition).description
            binding.tvSubjectDate.text=convertDateFormat(Notification_listdata.get(adapterPosition).createdAt!!)

        }
    }
}