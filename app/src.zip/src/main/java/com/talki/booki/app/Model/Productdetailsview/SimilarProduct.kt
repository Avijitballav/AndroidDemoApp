package com.talki.booki.app.Model.Productdetailsview

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SimilarProduct {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("slug")
    @Expose
    var slug: String? = null

    @SerializedName("thumbnail")
    @Expose
    var thumbnail: String? = null

    @SerializedName("author")
    @Expose
    var author: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("language_id")
    @Expose
    var languageId: Int? = null

    @SerializedName("narrator")
    @Expose
    var narrator: String? = null

    @SerializedName("publisher")
    @Expose
    var publisher: String? = null

    @SerializedName("promo_file")
    @Expose
    var promoFile: String? = null

    @SerializedName("paid_file")
    @Expose
    var paidFile: String? = null

    @SerializedName("duration")
    @Expose
    var duration: String? = null

    @SerializedName("share_url")
    @Expose
    var shareUrl: Any? = null

    @SerializedName("is_free")
    @Expose
    var isFree: Int? = null

    @SerializedName("created_by")
    @Expose
    var createdBy: Int? = null

    @SerializedName("updated_by")
    @Expose
    var updatedBy: Int? = null

    @SerializedName("is_active")
    @Expose
    var isActive: Int? = null

    @SerializedName("is_deleted")
    @Expose
    var isDeleted: Int? = null

    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null

    @SerializedName("deleted_at")
    @Expose
    var deletedAt: Any? = null
}